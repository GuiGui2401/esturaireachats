<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SizeChartDetail extends Model
{
    protected $guarded = [];
}
